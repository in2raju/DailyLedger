<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$uid = $_SESSION['user_id'];

$partyId = (int)get('id');
$stmt = $pdo->prepare("SELECT * FROM parties WHERE id=? AND user_id=?");
$stmt->execute([$partyId, $uid]);
$party = $stmt->fetch();
if (!$party) { flash('danger', 'Party not found.'); redirect('parties.php'); }

/* ---------------- Handle POST ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save_tx') {
        $id        = (int)post('id');
        // ইউজারের ব্রাউজার থেকে আসা লোকাল তারিখ ও সময়
        $localDate = post('local_date');   // e.g. 2026-09-23
        $localTime = post('local_time');   // e.g. 22:45:30
        $entryDate = post('entry_date');   // fallback / manual edit
        $txType    = post('tx_type') === 'payment' ? 'payment' : 'due';
        $amount    = clean_amount(post('amount'));
        $note      = trim(post('note'));

        // লোকাল তারিখ প্রায়োরিটি পাবে
        if ($localDate) {
            $entryDate = $localDate;
        }

        // লোকাল ডেটটাইম (created_at এর জন্য)
        $localDateTime = ($localDate && $localTime)
            ? $localDate . ' ' . $localTime
            : date('Y-m-d H:i:s');

        if (!$entryDate || $amount <= 0) {
            flash('danger', 'Please provide a valid date and amount.');
        } elseif ($id > 0) {
            $stmt = $pdo->prepare("UPDATE due_transactions SET entry_date=?, type=?, amount=?, note=?, created_at=? WHERE id=? AND party_id=? AND user_id=?");
            $stmt->execute([$entryDate, $txType, $amount, $note, $localDateTime, $id, $partyId, $uid]);
            flash('success', 'Transaction updated.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO due_transactions (party_id, user_id, entry_date, type, amount, note, created_at) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$partyId, $uid, $entryDate, $txType, $amount, $note, $localDateTime]);
            flash('success', ($txType === 'due' ? 'New due' : 'Payment') . ' recorded.');
        }
    } elseif ($action === 'delete_tx') {
        $id = (int)post('id');
        $stmt = $pdo->prepare("DELETE FROM due_transactions WHERE id=? AND party_id=? AND user_id=?");
        $stmt->execute([$id, $partyId, $uid]);
        flash('success', 'Transaction deleted.');
    }
    redirect('party_ledger.php?id=' . $partyId);
}

/* ---------------- Data ---------------- */
$stmt = $pdo->prepare("SELECT * FROM due_transactions WHERE party_id=? ORDER BY entry_date, id");
$stmt->execute([$partyId]);
$txs = $stmt->fetchAll();

$running = (float)$party['opening_due'];
$totalDue = $totalPaid = 0;
foreach ($txs as &$t) {
    if ($t['type'] === 'due') { $running += (float)$t['amount']; $totalDue += (float)$t['amount']; }
    else { $running -= (float)$t['amount']; $totalPaid += (float)$t['amount']; }
    $t['running'] = $running;
}
unset($t);
$currentDue = $running;
$txs = array_reverse($txs); // latest first for display

$isCustomer = $party['type'] === 'customer';
$pageTitle  = $party['name'];
$activeMenu = $isCustomer ? 'customers' : 'suppliers';
require_once __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-start mb-3 no-print flex-wrap gap-2">
  <div>
    <a href="parties.php?type=<?= $party['type'] ?>" class="text-decoration-none small"><i class="bi bi-arrow-left"></i> Back to <?= $isCustomer?'Customers':'Suppliers' ?></a>
    <h4 class="fw-bold mb-0 mt-1"><i class="bi bi-<?= $isCustomer?'person':'truck' ?>"></i> <?= e($party['name']) ?>
      <span class="badge <?= $isCustomer?'bg-warning text-dark':'bg-purple text-white' ?>" style="background:<?= $isCustomer?'#e8a33d':'#8e5cc4' ?>"><?= ucfirst($party['type']) ?></span>
    </h4>
    <div class="text-muted small"><?= e($party['phone']) ?> <?= $party['address'] ? '· '.e($party['address']) : '' ?></div>
  </div>
  <div class="text-end">
    <button class="btn btn-outline-secondary btn-sm" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>
    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#txModal" onclick="openTxModal('due')"><i class="bi bi-plus-lg"></i> New Due</button>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#txModal" onclick="openTxModal('payment')"><i class="bi bi-cash"></i> Record Payment</button>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-6 col-md-3">
    <div class="card stat-card bg-balance p-3"><div class="stat-label">Opening Due</div><div class="stat-value" style="font-size:1.3rem"><?= money($party['opening_due']) ?></div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card bg-income p-3"><div class="stat-label">New Due Added</div><div class="stat-value" style="font-size:1.3rem"><?= money($totalDue) ?></div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card bg-month p-3"><div class="stat-label">Payments Received/Paid</div><div class="stat-value" style="font-size:1.3rem"><?= money($totalPaid) ?></div></div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card <?= $isCustomer?'bg-receivable':'bg-payable' ?> p-3"><div class="stat-label">Current Due</div><div class="stat-value" style="font-size:1.3rem"><?= money($currentDue) ?></div></div>
  </div>
</div>

<div class="alert alert-light border small no-print">
  <b>Formula:</b> Opening Due (<?= money($party['opening_due']) ?>) + New Due (<?= money($totalDue) ?>) − Payment (<?= money($totalPaid) ?>) = <b>Current Due <?= money($currentDue) ?></b>
</div>

<div class="card">
  <div class="card-header">Transaction History</div>
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Note</th><th>Balance After</th><th class="no-print">Action</th></tr></thead>
      <tbody>
      <?php if (!$txs): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">No due/payment transactions yet.</td></tr>
      <?php endif; ?>
      <?php foreach ($txs as $t): ?>
        <tr>
          <td><?= date('d M Y', strtotime($t['entry_date'])) ?></td>
          <td><span class="badge <?= $t['type']==='due'?'bg-success':'bg-primary' ?>"><?= $t['type']==='due'?'New Due':'Payment' ?></span></td>
          <td class="fw-semibold"><?= money($t['amount']) ?></td>
          <td class="small text-muted"><?= e($t['note']) ?></td>
          <td><?= money($t['running']) ?></td>
          <td class="no-print">
            <button class="btn btn-sm btn-outline-primary" onclick='openTxModal("<?= $t['type'] ?>", <?= json_encode($t) ?>)'><i class="bi bi-pencil"></i></button>
            <form method="post" class="d-inline confirm-action" data-confirm="Delete this transaction?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete_tx">
              <input type="hidden" name="id" value="<?= $t['id'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="txModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content" id="txForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_tx">
      <input type="hidden" name="id" id="tx_id">
      <input type="hidden" name="tx_type" id="tx_type">
      <!-- ইউজারের ব্রাউজারের লোকাল তারিখ ও সময় -->
      <input type="hidden" name="local_date" id="local_date">
      <input type="hidden" name="local_time" id="local_time">

      <div class="modal-header">
        <h5 class="modal-title" id="txModalTitle">New Due</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2">
          <label class="form-label small">Date</label>
          <input type="date" name="entry_date" id="tx_date" class="form-control" required>
          <div class="form-text" id="localDateTimeHint"></div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Amount</label>
          <input type="number" step="0.01" min="0.01" name="amount" id="tx_amount" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label small">Note</label>
          <textarea name="note" id="tx_note" class="form-control" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
/* ===== ইউজারের ব্রাউজারের বর্তমান তারিখ ও সময় ===== */
function getLocalDateTime() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const yyyy = now.getFullYear();
  const mm   = pad(now.getMonth() + 1);
  const dd   = pad(now.getDate());
  const hh   = pad(now.getHours());
  const mi   = pad(now.getMinutes());
  const ss   = pad(now.getSeconds());
  return {
    date: `${yyyy}-${mm}-${dd}`,
    time: `${hh}:${mi}:${ss}`,
    display: now.toLocaleString(undefined, {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    })
  };
}

function setLocalDateTimeFields() {
  const dt = getLocalDateTime();
  document.getElementById('local_date').value = dt.date;
  document.getElementById('local_time').value = dt.time;
  document.getElementById('localDateTimeHint').textContent = 'Your local time: ' + dt.display;
  return dt;
}

/* ===== মডাল ওপেন ===== */
function openTxModal(type, data) {
  const dt = setLocalDateTimeFields();

  document.getElementById('tx_type').value = type;
  document.getElementById('tx_id').value = data ? data.id : '';
  document.getElementById('tx_date').value = data ? data.entry_date : dt.date; // লোকাল তারিখ ডিফল্ট
  document.getElementById('tx_amount').value = data ? data.amount : '';
  document.getElementById('tx_note').value = data ? data.note : '';
  document.getElementById('txModalTitle').textContent = (data ? 'Edit ' : '') + (type === 'due' ? 'New Due' : 'Record Payment');

  // এডিট মোডে থাকলে লোকাল তারিখ ওভাররাইড করবে না
  if (data) {
    document.getElementById('local_date').value = '';
    document.getElementById('local_time').value = '';
    document.getElementById('localDateTimeHint').textContent = 'Editing existing transaction — date unchanged.';
  }
}

/* ===== ফর্ম সাবমিটের আগে লোকাল তারিখ/সময় নিশ্চিত করা ===== */
document.getElementById('txForm').addEventListener('submit', function () {
  if (!document.getElementById('tx_id').value) {
    // নতুন ট্রানজেকশন → লোকাল তারিখ ও সময় সেট
    setLocalDateTimeFields();
  }
});

/* পেজ লোডে লোকাল তারিখ/সময় হিন্ট দেখাও */
document.addEventListener('DOMContentLoaded', setLocalDateTimeFields);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>