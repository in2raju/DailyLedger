<?php
// Expects: $pageTitle (string), $activeMenu (string) set by the including page.
$pageTitle  = $pageTitle  ?? 'Dashboard';
$activeMenu = $activeMenu ?? '';
$u = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand app-navbar fixed-top px-3">
  <button class="btn btn-link me-2 d-lg-none" id="sidebarToggle" type="button">
    <i class="bi bi-list fs-3"></i>
  </button>
  <a class="navbar-brand" href="dashboard.php"><i class="bi bi-journal-richtext me-1"></i><?= e(APP_NAME) ?></a>
  <div class="ms-auto d-flex align-items-center">
    <span class="text-white-50 small d-none d-sm-inline me-3">
      <i class="bi bi-shop"></i> <?= e($u['business_name'] ?: 'My Business') ?>
    </span>
    <div class="dropdown">
      <button class="btn btn-link text-white text-decoration-none dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="bi bi-person-circle fs-5"></i> <?= e($u['name']) ?>
        <span class="badge bg-warning text-dark ms-1"><?= e(ucfirst($u['role'])) ?></span>
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="profile.php"><i class="bi bi-gear me-2"></i>Change Password</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="sidebar" id="appSidebar" style="padding-top:56px;">
  <div class="nav-section">Overview</div>
  <ul class="nav flex-column">
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='dashboard'?'active':'' ?>" href="dashboard.php"><i class="bi bi-speedometer2"></i>Dashboard</a></li>
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='ledger'?'active':'' ?>" href="ledger.php"><i class="bi bi-journal-text"></i>Daily Ledger</a></li>
  </ul>

  <div class="nav-section">Transactions</div>
  <ul class="nav flex-column">
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='income'?'active':'' ?>" href="income.php"><i class="bi bi-graph-up-arrow"></i>Income</a></li>
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='expense'?'active':'' ?>" href="expense.php"><i class="bi bi-graph-down-arrow"></i>Expense</a></li>
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='heads'?'active':'' ?>" href="heads.php"><i class="bi bi-tags"></i>Income/Expense Heads</a></li>
  </ul>

  <div class="nav-section">Due Ledger</div>
  <ul class="nav flex-column">
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='customers'?'active':'' ?>" href="parties.php?type=customer"><i class="bi bi-people"></i>Customers (Receivable)</a></li>
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='suppliers'?'active':'' ?>" href="parties.php?type=supplier"><i class="bi bi-truck"></i>Suppliers (Payable)</a></li>
  </ul>

  <div class="nav-section">Reports</div>
  <ul class="nav flex-column">
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='reports'?'active':'' ?>" href="reports.php"><i class="bi bi-bar-chart-line"></i>Reports</a></li>
  </ul>

  <?php if (is_admin()): ?>
  <div class="nav-section">Administration</div>
  <ul class="nav flex-column mb-3">
    <li class="nav-item"><a class="nav-link <?= $activeMenu==='users'?'active':'' ?>" href="users.php"><i class="bi bi-person-badge"></i>Manage Users</a></li>
  </ul>
  <?php endif; ?>
</div>

<div class="sidebar-backdrop" id="sidebarBackdrop"></div>

<div class="content-wrap">
<?php $flashes = get_flashes(); if ($flashes): ?>
  <?php foreach ($flashes as $f): ?>
    <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show auto-dismiss no-print" role="alert">
      <?= e($f['message']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endforeach; ?>
<?php endif; ?>
