document.addEventListener('DOMContentLoaded', function () {
  /* ---------------- Responsive sidebar ---------------- */
  var toggleBtn = document.getElementById('sidebarToggle');
  var sidebar   = document.getElementById('appSidebar');
  var backdrop  = document.getElementById('sidebarBackdrop');

  function openSidebar() {
    sidebar.classList.add('show');
    if (backdrop) backdrop.classList.add('show');
  }
  function closeSidebar() {
    sidebar.classList.remove('show');
    if (backdrop) backdrop.classList.remove('show');
  }

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      if (sidebar.classList.contains('show')) {
        closeSidebar();
      } else {
        openSidebar();
      }
    });

    // Tapping the dark overlay closes the menu
    if (backdrop) {
      backdrop.addEventListener('click', closeSidebar);
    }

    // Close the menu once a link inside it is tapped (mobile UX)
    sidebar.querySelectorAll('a.nav-link').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 992) closeSidebar();
      });
    });

    // If the viewport grows back to desktop size, make sure mobile state is reset
    window.addEventListener('resize', function () {
      if (window.innerWidth >= 992) closeSidebar();
    });
  }

  // Auto-dismiss alerts
  document.querySelectorAll('.alert.auto-dismiss').forEach(function (alertEl) {
    setTimeout(function () {
      var a = bootstrap.Alert.getOrCreateInstance(alertEl);
      a.close();
    }, 4000);
  });

  // Confirm before delete / destructive actions
  document.querySelectorAll('.confirm-action').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      var msg = form.getAttribute('data-confirm') || 'Are you sure?';
      if (!confirm(msg)) e.preventDefault();
    });
  });

  // Live filter form auto-submit
  document.querySelectorAll('.auto-filter').forEach(function (el) {
    el.addEventListener('change', function () {
      el.closest('form').submit();
    });
  });
});
