<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$uid = $_SESSION['user_id'];

/* ---------------- Handle POST (create / update / delete) ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        $id       = (int)post('id');
        // ইউজারের ব্রাউজার থেকে আসা লোকাল তারিখ ও সময়
        $localDate = post('local_date');   // e.g. 2026-09-23
        $localTime = post('local_time');   // e.g. 22:45:30
        $entryDate = post('entry_date');   // fallback / manual edit
        $headId    = (int)post('head_id');
        $amount    = clean_amount(post('amount'));
        $method    = post('payment_method', 'Cash');
        $note      = trim(post('note'));

        // লোকাল তারিখ প্রায়োরিটি পাবে, না থাকলে ম্যানুয়াল entry_date
        if ($localDate) {
            $entryDate = $localDate;
        }

        // লোকাল ডেটটাইম (created_at এর জন্য)
        $localDateTime = ($localDate && $localTime)
            ? $localDate . ' ' . $localTime
            : date('Y-m-d H:i:s');

        if (!$entryDate || !$headId || $amount <= 0) {
            flash('danger', 'Please fill date, head and a valid amount.');
        } else {
            if ($id > 0) {
                $stmt = $pdo->prepare("UPDATE incomes SET entry_date=?, head_id=?, amount=?, payment_method=?, note=?, created_at=? WHERE id=? AND user_id=?");
                $stmt->execute([$entryDate, $headId, $amount, $method, $note, $localDateTime, $id, $uid]);
                flash('success', 'Income entry updated.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO incomes (user_id, entry_date, head_id, amount, payment_method, note, created_at) VALUES (?,?,?,?,?,?,?)");
                $stmt->execute([$uid, $entryDate, $headId, $amount, $method, $note, $localDateTime]);
                flash('success', 'Income entry added.');
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        $stmt = $pdo->prepare("DELETE FROM incomes WHERE id=? AND user_id=?");
        $stmt->execute([$id, $uid]);
        flash('success', 'Income entry deleted.');
    }
    redirect('income.php' . (isset($_GET) && $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : ''));
}

/* ---------------- Filters ---------------- */
$search   = trim(get('q'));
$headFil  = (int)get('head_id');
$methodFil= get('payment_method');
$from     = get('from');
$to       = get('to');
$page     = max(1, (int)get('page', 1));
$perPage  = 15;

$where  = "WHERE i.user_id = ?";
$params = [$uid];

if ($search !== '') { $where .= " AND (i.note LIKE ? OR ih.name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($headFil)        { $where .= " AND i.head_id = ?"; $params[] = $headFil; }
if ($methodFil)       { $where .= " AND i.payment_method = ?"; $params[] = $methodFil; }
if ($from)             { $where .= " AND i.entry_date >= ?"; $params[] = $from; }
if ($to)               { $where .= " AND i.entry_date <= ?"; $params[] = $to; }

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM incomes i JOIN income_heads ih ON ih.id=i.head_id $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$p = paginate($total, $perPage, $page);

$sql = "SELECT i.*, ih.name AS head_name FROM incomes i JOIN income_heads ih ON ih.id=i.head_id $where ORDER BY i.entry_date DESC, i.id DESC LIMIT $perPage OFFSET {$p['offset']}";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$sumStmt = $pdo->prepare("SELECT COALESCE(SUM(i.amount),0) FROM incomes i JOIN income_heads ih ON ih.id=i.head_id $where");
$sumStmt->execute($params);
$sumTotal = (float)$sumStmt->fetchColumn();

$heads = $pdo->prepare("SELECT * FROM income_heads WHERE user_id=? AND status='active' ORDER BY name");
$heads->execute([$uid]);
$heads = $heads->fetchAll();

$pageTitle = 'Income'; $activeMenu = 'income';
require_once __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 no-print">
  <h4 class="fw-bold mb-0"><i class="bi bi-graph-up-arrow text-success"></i> Income Entries</h4>
  <div>
    <button class="btn btn-outline-secondary btn-sm" onclick="window.print()"><i class="bi bi-printer"></i> Print</button>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#incomeModal" onclick="openIncomeModal()"><i class="bi bi-plus-lg"></i> Add Income</button>
  </div>
</div>

<div class="card mb-3 no-print">
  <div class="card-body">
    <form method="get" class="row g-2 align-items-end">
      <div class="col-md-3">
        <label class="form-label small mb-1">Search</label>
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Note or head..." value="<?= e($search) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">Head</label>
        <select name="head_id" class="form-select form-select-sm">
          <option value="">All</option>
          <?php foreach ($heads as $h): ?>
            <option value="<?= $h['id'] ?>" <?= $headFil==$h['id']?'selected':'' ?>><?= e($h['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">Payment Method</label>
        <select name="payment_method" class="form-select form-select-sm">
          <option value="">All</option>
          <?php foreach (['Cash','Bank','Mobile Banking','Card','Other'] as $m): ?>
            <option value="<?= $m ?>" <?= $methodFil==$m?'selected':'' ?>><?= $m ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">From</label>
        <input type="date" name="from" class="form-control form-control-sm" value="<?= e($from) ?>">
      </div>
      <div class="col-md-2">
        <label class="form-label small mb-1">To</label>
        <input type="date" name="to" class="form-control form-control-sm" value="<?= e($to) ?>">
      </div>
      <div class="col-md-1 d-grid">
        <button class="btn btn-sm btn-primary"><i class="bi bi-search"></i></button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between">
    <span>Income List</span>
    <span class="text-success fw-bold">Total: <?= money($sumTotal) ?></span>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead><tr><th>Date</th><th>Head</th><th>Amount</th><th>Method</th><th>Note</th><th class="no-print">Action</th></tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">No income entries found.</td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= date('d M Y', strtotime($r['entry_date'])) ?></td>
          <td><?= e($r['head_name']) ?></td>
          <td class="fw-semibold text-success"><?= money($r['amount']) ?></td>
          <td><span class="badge bg-light text-dark border"><?= e($r['payment_method']) ?></span></td>
          <td class="small text-muted"><?= e($r['note']) ?></td>
          <td class="no-print">
            <button class="btn btn-sm btn-outline-primary" onclick='openIncomeModal(<?= json_encode($r) ?>)'><i class="bi bi-pencil"></i></button>
            <form method="post" class="d-inline confirm-action" data-confirm="Delete this income entry?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer no-print">
    <?= pagination_links('income.php', ['q'=>$search,'head_id'=>$headFil,'payment_method'=>$methodFil,'from'=>$from,'to'=>$to], $p['currentPage'], $p['totalPages']) ?>
  </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="incomeModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content" id="incomeForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="inc_id">
      <!-- ইউজারের ব্রাউজারের লোকাল তারিখ ও সময় -->
      <input type="hidden" name="local_date" id="local_date">
      <input type="hidden" name="local_time" id="local_time">

      <div class="modal-header">
        <h5 class="modal-title" id="incModalTitle">Add Income</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2">
          <label class="form-label small">Date</label>
          <input type="date" name="entry_date" id="inc_date" class="form-control" required>
          <div class="form-text" id="localDateTimeHint"></div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Income Head</label>
          <select name="head_id" id="inc_head" class="form-select" required>
            <?php foreach ($heads as $h): ?>
              <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Need a new head? <a href="heads.php" target="_blank">Manage heads</a></div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Amount</label>
          <input type="number" step="0.01" min="0.01" name="amount" id="inc_amount" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label small">Payment Method</label>
          <select name="payment_method" id="inc_method" class="form-select">
            <?php foreach (['Cash','Bank','Mobile Banking','Card','Other'] as $m): ?>
              <option value="<?= $m ?>"><?= $m ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label small">Note</label>
          <textarea name="note" id="inc_note" class="form-control" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
/* ===== ইউজারের ব্রাউজারের বর্তমান তারিখ ও সময় ===== */
function getLocalDateTime() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  const yyyy = now.getFullYear();
  const mm   = pad(now.getMonth() + 1);
  const dd   = pad(now.getDate());
  const hh   = pad(now.getHours());
  const mi   = pad(now.getMinutes());
  const ss   = pad(now.getSeconds());
  return {
    date: `${yyyy}-${mm}-${dd}`,
    time: `${hh}:${mi}:${ss}`,
    display: now.toLocaleString(undefined, {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    })
  };
}

function setLocalDateTimeFields() {
  const dt = getLocalDateTime();
  document.getElementById('local_date').value = dt.date;
  document.getElementById('local_time').value = dt.time;
  document.getElementById('localDateTimeHint').textContent = 'Your local time: ' + dt.display;
  return dt;
}

/* ===== মডাল ওপেন ===== */
function openIncomeModal(data) {
  const dt = setLocalDateTimeFields();

  document.getElementById('incModalTitle').textContent = data ? 'Edit Income' : 'Add Income';
  document.getElementById('inc_id').value = data ? data.id : '';
  document.getElementById('inc_date').value = data ? data.entry_date : dt.date; // লোকাল তারিখ ডিফল্ট
  document.getElementById('inc_head').value = data ? data.head_id : '';
  document.getElementById('inc_amount').value = data ? data.amount : '';
  document.getElementById('inc_method').value = data ? data.payment_method : 'Cash';
  document.getElementById('inc_note').value = data ? data.note : '';

  // এডিট মোডে থাকলে লোকাল তারিখ ওভাররাইড করবে না
  if (data) {
    document.getElementById('local_date').value = '';
    document.getElementById('local_time').value = '';
    document.getElementById('localDateTimeHint').textContent = 'Editing existing entry — date unchanged.';
  }
}

/* ===== ফর্ম সাবমিটের আগে লোকাল তারিখ/সময় নিশ্চিত করা ===== */
document.getElementById('incomeForm').addEventListener('submit', function () {
  if (!document.getElementById('inc_id').value) {
    // নতুন এন্ট্রি → লোকাল তারিখ ও সময় সেট
    setLocalDateTimeFields();
  }
});

/* পেজ লোডে লোকাল তারিখ/সময় হিন্ট দেখাও */
document.addEventListener('DOMContentLoaded', setLocalDateTimeFields);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>