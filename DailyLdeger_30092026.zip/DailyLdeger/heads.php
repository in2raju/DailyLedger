<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$uid = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');
    $table  = post('kind') === 'expense' ? 'expense_heads' : 'income_heads';
    $label  = post('kind') === 'expense' ? 'Expense head' : 'Income head';

    if ($action === 'save') {
        $id   = (int)post('id');
        $name = trim(post('name'));
        if ($name === '') {
            flash('danger', 'Please enter a name.');
        } else {
            try {
                if ($id > 0) {
                    $stmt = $pdo->prepare("UPDATE $table SET name=? WHERE id=? AND user_id=?");
                    $stmt->execute([$name, $id, $uid]);
                    flash('success', "$label updated.");
                } else {
                    $stmt = $pdo->prepare("INSERT INTO $table (user_id, name) VALUES (?,?)");
                    $stmt->execute([$uid, $name]);
                    flash('success', "$label added.");
                }
            } catch (PDOException $ex) {
                flash('danger', "$label with this name already exists.");
            }
        }
    } elseif ($action === 'toggle') {
        $id = (int)post('id');
        $stmt = $pdo->prepare("UPDATE $table SET status = IF(status='active','inactive','active') WHERE id=? AND user_id=?");
        $stmt->execute([$id, $uid]);
        flash('success', "$label status updated.");
    } elseif ($action === 'delete') {
        $id = (int)post('id');
        try {
            $stmt = $pdo->prepare("DELETE FROM $table WHERE id=? AND user_id=?");
            $stmt->execute([$id, $uid]);
            flash('success', "$label deleted.");
        } catch (PDOException $ex) {
            flash('danger', "Cannot delete: this head is already used in transactions. Deactivate it instead.");
        }
    }
    redirect('heads.php');
}

$incomeHeads = $pdo->prepare("SELECT ih.*, (SELECT COUNT(*) FROM incomes i WHERE i.head_id=ih.id) AS usage_count FROM income_heads ih WHERE user_id=? ORDER BY name");
$incomeHeads->execute([$uid]);
$incomeHeads = $incomeHeads->fetchAll();

$expenseHeads = $pdo->prepare("SELECT eh.*, (SELECT COUNT(*) FROM expenses e WHERE e.head_id=eh.id) AS usage_count FROM expense_heads eh WHERE user_id=? ORDER BY name");
$expenseHeads->execute([$uid]);
$expenseHeads = $expenseHeads->fetchAll();

$pageTitle = 'Income/Expense Heads'; $activeMenu = 'heads';
require_once __DIR__ . '/includes/header.php';
?>

<h4 class="fw-bold mb-3"><i class="bi bi-tags text-primary-dl"></i> Manage Income &amp; Expense Heads</h4>

<div class="row g-3">
  <!-- Income Heads -->
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-graph-up-arrow text-success"></i> Income Heads</span>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#headModal" onclick="openHeadModal('income')"><i class="bi bi-plus-lg"></i> Add</button>
      </div>
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Name</th><th>Used</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
          <?php if (!$incomeHeads): ?><tr><td colspan="4" class="text-center text-muted py-3">No income heads yet.</td></tr><?php endif; ?>
          <?php foreach ($incomeHeads as $h): ?>
            <tr>
              <td><?= e($h['name']) ?></td>
              <td class="small text-muted"><?= (int)$h['usage_count'] ?>×</td>
              <td>
                <span class="badge <?= $h['status']==='active'?'bg-success':'bg-secondary' ?>"><?= ucfirst($h['status']) ?></span>
              </td>
              <td>
                <button class="btn btn-sm btn-outline-primary" onclick='openHeadModal("income", <?= json_encode($h) ?>)'><i class="bi bi-pencil"></i></button>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="kind" value="income">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= $h['id'] ?>">
                  <button class="btn btn-sm btn-outline-secondary" title="Activate/Deactivate"><i class="bi bi-power"></i></button>
                </form>
                <?php if ((int)$h['usage_count'] === 0): ?>
                <form method="post" class="d-inline confirm-action" data-confirm="Delete this income head?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="kind" value="income">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= $h['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Expense Heads -->
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-graph-down-arrow text-danger"></i> Expense Heads</span>
        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#headModal" onclick="openHeadModal('expense')"><i class="bi bi-plus-lg"></i> Add</button>
      </div>
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Name</th><th>Used</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
          <?php if (!$expenseHeads): ?><tr><td colspan="4" class="text-center text-muted py-3">No expense heads yet.</td></tr><?php endif; ?>
          <?php foreach ($expenseHeads as $h): ?>
            <tr>
              <td><?= e($h['name']) ?></td>
              <td class="small text-muted"><?= (int)$h['usage_count'] ?>×</td>
              <td>
                <span class="badge <?= $h['status']==='active'?'bg-success':'bg-secondary' ?>"><?= ucfirst($h['status']) ?></span>
              </td>
              <td>
                <button class="btn btn-sm btn-outline-primary" onclick='openHeadModal("expense", <?= json_encode($h) ?>)'><i class="bi bi-pencil"></i></button>
                <form method="post" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="kind" value="expense">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= $h['id'] ?>">
                  <button class="btn btn-sm btn-outline-secondary" title="Activate/Deactivate"><i class="bi bi-power"></i></button>
                </form>
                <?php if ((int)$h['usage_count'] === 0): ?>
                <form method="post" class="d-inline confirm-action" data-confirm="Delete this expense head?">
                  <?= csrf_field() ?>
                  <input type="hidden" name="kind" value="expense">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= $h['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add/Edit Head Modal -->
<div class="modal fade" id="headModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="kind" id="head_kind">
      <input type="hidden" name="id" id="head_id">
      <div class="modal-header">
        <h5 class="modal-title" id="headModalTitle">Add Head</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label small">Name</label>
        <input type="text" name="name" id="head_name" class="form-control" required maxlength="100">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openHeadModal(kind, data) {
  document.getElementById('head_kind').value = kind;
  document.getElementById('head_id').value = data ? data.id : '';
  document.getElementById('head_name').value = data ? data.name : '';
  var titleKind = kind === 'expense' ? 'Expense' : 'Income';
  document.getElementById('headModalTitle').textContent = (data ? 'Edit ' : 'Add ') + titleKind + ' Head';
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
