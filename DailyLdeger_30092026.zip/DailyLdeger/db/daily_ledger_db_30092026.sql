-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2026 at 03:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daily_ledger`
--

-- --------------------------------------------------------

--
-- Table structure for table `due_transactions`
--

CREATE TABLE `due_transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `party_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `entry_date` date NOT NULL,
  `type` enum('due','payment') NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `due_transactions`
--

INSERT INTO `due_transactions` (`id`, `party_id`, `user_id`, `entry_date`, `type`, `amount`, `note`, `created_at`) VALUES
(1, 1, 1, '2026-09-23', 'payment', 200.00, '', '2026-09-23 20:32:27');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `entry_date` date NOT NULL,
  `head_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('Cash','Bank','Mobile Banking','Card','Other') NOT NULL DEFAULT 'Cash',
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `user_id`, `entry_date`, `head_id`, `amount`, `payment_method`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, '2026-09-23', 1, 500.00, 'Cash', 'filtere', '2026-09-23 20:30:46', '2026-09-23 20:30:46'),
(2, 2, '2026-09-29', 7, 2000.00, 'Cash', '', '2026-09-30 19:17:47', '2026-09-30 19:26:44'),
(3, 2, '2026-09-30', 7, 2500.00, 'Cash', '', '2026-09-30 19:23:33', '2026-09-30 19:23:33');

-- --------------------------------------------------------

--
-- Table structure for table `expense_heads`
--

CREATE TABLE `expense_heads` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense_heads`
--

INSERT INTO `expense_heads` (`id`, `user_id`, `name`, `status`, `created_at`) VALUES
(1, 1, 'Purchase', 'active', '2026-09-22 20:16:33'),
(2, 1, 'Rent', 'active', '2026-09-22 20:16:33'),
(3, 1, 'Utility Bill', 'active', '2026-09-22 20:16:33'),
(4, 1, 'Salary', 'active', '2026-09-22 20:16:33'),
(5, 1, 'Transport', 'active', '2026-09-22 20:16:33'),
(6, 1, 'Other Expense', 'active', '2026-09-22 20:16:33'),
(7, 2, 'Rent', 'active', '2026-09-30 19:14:59');

-- --------------------------------------------------------

--
-- Table structure for table `incomes`
--

CREATE TABLE `incomes` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `entry_date` date NOT NULL,
  `head_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('Cash','Bank','Mobile Banking','Card','Other') NOT NULL DEFAULT 'Cash',
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `incomes`
--

INSERT INTO `incomes` (`id`, `user_id`, `entry_date`, `head_id`, `amount`, `payment_method`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, '2026-09-23', 3, 9000.00, 'Cash', '', '2026-09-23 20:30:26', '2026-09-23 20:30:26'),
(2, 2, '2026-09-30', 4, 25600.00, 'Cash', '', '2026-09-30 19:15:24', '2026-09-30 19:15:24'),
(3, 2, '2026-09-29', 4, 2560.00, 'Cash', '', '2026-09-30 19:23:20', '2026-09-30 19:26:28');

-- --------------------------------------------------------

--
-- Table structure for table `income_heads`
--

CREATE TABLE `income_heads` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `income_heads`
--

INSERT INTO `income_heads` (`id`, `user_id`, `name`, `status`, `created_at`) VALUES
(1, 1, 'Product Sales', 'active', '2026-09-22 20:16:33'),
(2, 1, 'Service Income', 'active', '2026-09-22 20:16:33'),
(3, 1, 'Other Income', 'active', '2026-09-22 20:16:33'),
(4, 2, 'Sales Product', 'active', '2026-09-30 19:14:52');

-- --------------------------------------------------------

--
-- Table structure for table `parties`
--

CREATE TABLE `parties` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` enum('customer','supplier') NOT NULL,
  `name` varchar(120) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `opening_due` decimal(14,2) NOT NULL DEFAULT 0.00,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parties`
--

INSERT INTO `parties` (`id`, `user_id`, `type`, `name`, `phone`, `address`, `opening_due`, `status`, `created_at`) VALUES
(1, 1, 'customer', 'raju das', '02223374901', 'Noapara, raozan, chittagong', 1000.00, 'active', '2026-09-23 20:31:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `business_name` varchar(150) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `business_name`, `password`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin', 'admin@example.com', NULL, 'My Shop', '$2y$10$9nhVkkahBbK/fuXr3mR1zOWNdll4pHEJKXw3go7gc5JsqotD7l4da', 'admin', 'active', '2026-09-22 20:16:33', '2026-09-22 20:16:33'),
(2, 'raju das', 'shop24', 'rajucsecu@gmail.com', '02223374901', 'Shop24', '$2y$10$CJ10.vdUf9Ge26QZHgULnek57eY/7V4eT3QR9MWbpSXPJT8h5MA5a', 'user', 'active', '2026-09-23 20:41:17', '2026-09-30 19:11:44'),
(3, 'softadmin', 'softadmin', 'rajucsecu@gmail.com', '02223374901', 'Soft Admin', '$2y$10$zfVcQBNMdoLvtbZnRJP0s.yZ9BTJZ0V8L.8G70py5Ev1RYuxFGtse', 'admin', 'active', '2026-09-23 20:42:24', '2026-09-23 20:44:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `due_transactions`
--
ALTER TABLE `due_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_due_party` (`party_id`,`entry_date`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `head_id` (`head_id`),
  ADD KEY `idx_expense_date` (`user_id`,`entry_date`);

--
-- Indexes for table `expense_heads`
--
ALTER TABLE `expense_heads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_expense_head` (`user_id`,`name`);

--
-- Indexes for table `incomes`
--
ALTER TABLE `incomes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `head_id` (`head_id`),
  ADD KEY `idx_income_date` (`user_id`,`entry_date`);

--
-- Indexes for table `income_heads`
--
ALTER TABLE `income_heads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_income_head` (`user_id`,`name`);

--
-- Indexes for table `parties`
--
ALTER TABLE `parties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_party_type` (`user_id`,`type`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `due_transactions`
--
ALTER TABLE `due_transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expense_heads`
--
ALTER TABLE `expense_heads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `incomes`
--
ALTER TABLE `incomes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `income_heads`
--
ALTER TABLE `income_heads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `parties`
--
ALTER TABLE `parties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `due_transactions`
--
ALTER TABLE `due_transactions`
  ADD CONSTRAINT `due_transactions_ibfk_1` FOREIGN KEY (`party_id`) REFERENCES `parties` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `due_transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`head_id`) REFERENCES `expense_heads` (`id`);

--
-- Constraints for table `expense_heads`
--
ALTER TABLE `expense_heads`
  ADD CONSTRAINT `expense_heads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `incomes`
--
ALTER TABLE `incomes`
  ADD CONSTRAINT `incomes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `incomes_ibfk_2` FOREIGN KEY (`head_id`) REFERENCES `income_heads` (`id`);

--
-- Constraints for table `income_heads`
--
ALTER TABLE `income_heads`
  ADD CONSTRAINT `income_heads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `parties`
--
ALTER TABLE `parties`
  ADD CONSTRAINT `parties_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
