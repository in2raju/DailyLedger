<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim(post('username'));
    $password = post('password');

    if ($username === '' || $password === '') {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            $error = 'Invalid username or password.';
        } elseif ($user['status'] !== 'active') {
            $error = 'Your account has been deactivated. Please contact the administrator.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id']       = $user['id'];
            $_SESSION['user_name']     = $user['name'];
            $_SESSION['username']      = $user['username'];
            $_SESSION['role']          = $user['role'];
            $_SESSION['business_name'] = $user['business_name'];
            redirect('dashboard.php');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login · <?= e(APP_NAME) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  :root{
    /* ==== আপনার থিম কালার ==== */
    --dl-primary: #2f6f4e;
    --dl-primary-dark: #21543a;
    --dl-accent: #e8a33d;
    --dl-danger: #c0392b;
    --dl-bg: #f4f6f5;
    --dl-ink: #1f2d26;
    --dl-muted: #6b7c74;
    --dl-line: rgba(47,111,78,.16);
  }
  *{ font-family:'Inter', 'Segoe UI', Roboto, -apple-system, Arial, sans-serif; }
  html,body{ height:100%; }
  body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:24px;
    position:relative;
    overflow-x:hidden;
    color:var(--dl-ink);
    background-color:var(--dl-bg);
  }

  /* ===== Lightweight business ledger background ===== */
  .bg-layer{
    position:fixed;
    inset:0;
    z-index:0;
    pointer-events:none;
    overflow:hidden;
  }
  .bg-layer::before{
    content:"";
    position:absolute;
    inset:0;
    background:
      radial-gradient(900px 500px at 8% 0%,   rgba(47,111,78,.12), transparent 60%),
      radial-gradient(800px 500px at 100% 100%, rgba(232,163,61,.14), transparent 60%),
      radial-gradient(600px 400px at 60% -10%,  rgba(33,84,58,.10), transparent 60%),
      linear-gradient(180deg, #f7f9f8 0%, var(--dl-bg) 100%);
  }
  /* ledger grid lines */
  .bg-grid{
    position:absolute;
    inset:0;
    background-image:
      linear-gradient(to right, rgba(47,111,78,.10) 1px, transparent 1px),
      linear-gradient(to bottom, rgba(47,111,78,.08) 1px, transparent 1px);
    background-size:56px 56px;
    -webkit-mask-image:radial-gradient(circle at 50% 40%, #000 0%, transparent 78%);
            mask-image:radial-gradient(circle at 50% 40%, #000 0%, transparent 78%);
    opacity:.85;
  }
  /* floating ledger icons */
  .bg-icons{ position:absolute; inset:0; }
  .bg-icons i{
    position:absolute;
    font-size:2rem;
    color:rgba(47,111,78,.12);
    animation:drift 16s ease-in-out infinite;
  }
  .bg-icons i:nth-child(1){ top:12%; left:8%;  font-size:2.4rem; color:rgba(47,111,78,.16);  animation-duration:18s; }
  .bg-icons i:nth-child(2){ top:72%; left:12%; font-size:2.1rem; color:rgba(192,57,43,.13);  animation-duration:22s; animation-delay:-3s; }
  .bg-icons i:nth-child(3){ top:20%; right:10%; font-size:2.6rem; color:rgba(232,163,61,.20); animation-duration:20s; animation-delay:-6s; }
  .bg-icons i:nth-child(4){ top:66%; right:14%; font-size:2.0rem; color:rgba(47,111,78,.14);  animation-duration:24s; animation-delay:-2s; }
  .bg-icons i:nth-child(5){ top:44%; left:4%;  font-size:1.8rem; color:rgba(33,84,58,.14);   animation-duration:19s; animation-delay:-8s; }
  .bg-icons i:nth-child(6){ top:40%; right:4%; font-size:1.9rem; color:rgba(232,163,61,.16); animation-duration:21s; animation-delay:-5s; }
  @keyframes drift{
    0%,100%{ transform:translateY(0) rotate(0deg); }
    50%{ transform:translateY(-18px) rotate(6deg); }
  }
  /* soft corner glows */
  .bg-glow{
    position:absolute;
    border-radius:50%;
    filter:blur(70px);
    opacity:.30;
  }
  .bg-glow.g1{ width:340px;height:340px; top:-100px; left:-100px; background:linear-gradient(135deg,var(--dl-primary),#3d8f65); }
  .bg-glow.g2{ width:380px;height:380px; bottom:-140px; right:-120px; background:linear-gradient(135deg,var(--dl-accent),#f0b95f); opacity:.28; }

  /* ===== Login card ===== */
  .login-wrap{
    width:100%;
    max-width:440px;
    position:relative;
    z-index:2;
    animation:rise .6s cubic-bezier(.2,.8,.2,1) both;
  }
  @keyframes rise{
    from{ opacity:0; transform:translateY(20px) scale(.985); }
    to{ opacity:1; transform:translateY(0) scale(1); }
  }

  .login-card{
    position:relative;
    border:1px solid rgba(255,255,255,.9);
    border-radius:22px;
    background:rgba(255,255,255,.94);
    backdrop-filter:blur(14px);
    -webkit-backdrop-filter:blur(14px);
    box-shadow:
      0 24px 50px -24px rgba(31,45,38,.32),
      0 8px 22px -14px rgba(47,111,78,.35),
      inset 0 1px 0 rgba(255,255,255,.9);
    padding:40px 34px 30px;
    overflow:hidden;
  }
  .login-card::before{
    content:"";
    position:absolute;
    inset:0 0 auto 0;
    height:5px;
    background:linear-gradient(90deg, var(--dl-primary), var(--dl-accent), var(--dl-primary-dark));
    background-size:200% 100%;
    animation:shine 6s linear infinite;
  }
  @keyframes shine{
    0%{ background-position:0% 50%; }
    100%{ background-position:200% 50%; }
  }

  .brand-icon{
    width:68px;height:68px;
    margin:0 auto 16px;
    border-radius:18px;
    display:grid;
    place-items:center;
    font-size:30px;
    color:#fff;
    background:linear-gradient(135deg, var(--dl-primary), var(--dl-primary-dark));
    box-shadow:
      0 12px 26px -10px rgba(47,111,78,.7),
      inset 0 2px 0 rgba(255,255,255,.25);
  }

  .brand-title{
    font-weight:800;
    letter-spacing:-.02em;
    color:var(--dl-ink);
    font-size:1.45rem;
  }
  .brand-sub{
    color:var(--dl-muted);
    font-size:.84rem;
    font-weight:500;
  }

  /* ledger chips */
  .ledger-chips{
    display:flex;
    justify-content:center;
    gap:8px;
    margin:14px 0 22px;
    flex-wrap:wrap;
  }
  .ledger-chip{
    display:inline-flex;
    align-items:center;
    gap:6px;
    font-size:.7rem;
    font-weight:600;
    padding:5px 10px;
    border-radius:999px;
    border:1px solid var(--dl-line);
    background:rgba(244,246,245,.9);
    color:#4a5a52;
  }
  .ledger-chip.income{  color:var(--dl-primary-dark); background:rgba(47,111,78,.10);  border-color:rgba(47,111,78,.25); }
  .ledger-chip.expense{ color:var(--dl-danger);       background:rgba(192,57,43,.10); border-color:rgba(192,57,43,.25); }
  .ledger-chip.accent{  color:#a1650f;                background:rgba(232,163,61,.14);border-color:rgba(232,163,61,.3); }

  .form-label{
    color:#3b4a43;
    font-size:.76rem;
    font-weight:600;
    letter-spacing:.03em;
    text-transform:uppercase;
    margin-bottom:6px;
  }

  .input-group{
    border-radius:13px;
    overflow:hidden;
    box-shadow:0 1px 2px rgba(31,45,38,.04);
    transition:box-shadow .22s ease, transform .22s ease;
  }
  .input-group:focus-within{
    box-shadow:0 0 0 4px rgba(47,111,78,.15), 0 6px 16px -10px rgba(47,111,78,.55);
    transform:translateY(-1px);
  }
  .input-group-text{
    background:linear-gradient(180deg,#f8faf9,#eef3f0);
    border:1px solid #dde5e1;
    border-right:0;
    color:var(--dl-primary);
    font-size:1rem;
    padding:0 14px;
  }
  .form-control{
    border:1px solid #dde5e1;
    border-left:0;
    padding:12px 14px;
    font-size:.95rem;
    background:#fff;
    transition:border-color .2s ease;
  }
  .form-control:focus{
    box-shadow:none;
    border-color:#dde5e1;
    background:#fff;
  }
  .form-control::placeholder{ color:#9aa8a2; }

  .btn-login{
    position:relative;
    border:0;
    border-radius:13px;
    padding:13px 18px;
    font-weight:700;
    letter-spacing:.01em;
    color:#fff;
    background:linear-gradient(135deg, var(--dl-primary), var(--dl-primary-dark));
    box-shadow:0 14px 26px -14px rgba(47,111,78,.9);
    transition:transform .2s ease, box-shadow .2s ease;
    overflow:hidden;
  }
  .btn-login::after{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(135deg, var(--dl-primary-dark), var(--dl-accent));
    opacity:0;
    transition:opacity .3s ease;
    z-index:0;
  }
  .btn-login span,
  .btn-login i{ position:relative; z-index:1; }
  .btn-login:hover{
    transform:translateY(-2px);
    box-shadow:0 20px 34px -16px rgba(47,111,78,.95);
  }
  .btn-login:hover::after{ opacity:1; }
  .btn-login:active{ transform:translateY(0); }

  .alert{
    border:0;
    border-radius:13px;
    background:linear-gradient(135deg,#fdecea,#f9d6d2);
    color:var(--dl-danger);
    font-weight:500;
    display:flex;
    align-items:center;
    gap:8px;
  }
  .alert i{ font-size:1.05rem; }

  .divider{
    display:flex;
    align-items:center;
    gap:12px;
    color:#9aa8a2;
    font-size:.7rem;
    font-weight:600;
    letter-spacing:.14em;
    text-transform:uppercase;
    margin:22px 0 14px;
  }
  .divider::before,
  .divider::after{
    content:"";
    flex:1;
    height:1px;
    background:linear-gradient(90deg,transparent,#d5ddd9,transparent);
  }

  .foot-note{
    text-align:center;
    color:#9aa8a2;
    font-size:.76rem;
    margin-top:16px;
  }
  .foot-note strong{ color:var(--dl-primary); }

  @media (max-width:480px){
    .login-card{ padding:32px 22px 24px; border-radius:18px; }
    .brand-icon{ width:60px;height:60px;font-size:26px; }
    .brand-title{ font-size:1.28rem; }
  }
</style>
</head>
<body>

<!-- ===== Lightweight business ledger background ===== -->
<div class="bg-layer">
  <div class="bg-grid"></div>
  <div class="bg-glow g1"></div>
  <div class="bg-glow g2"></div>
  <div class="bg-icons">
    <i class="bi bi-cash-coin"></i>
    <i class="bi bi-receipt"></i>
    <i class="bi bi-graph-up-arrow"></i>
    <i class="bi bi-wallet2"></i>
    <i class="bi bi-journal-text"></i>
    <i class="bi bi-calculator"></i>
  </div>
</div>

<div class="login-wrap">
  <div class="login-card">
    <div class="brand-icon"><i class="bi bi-journal-richtext"></i></div>
    <h4 class="text-center brand-title mb-1"><?= e(APP_NAME) ?></h4>
    <p class="text-center brand-sub mb-0">দৈনিক আর্থিক ব্যবস্থাপনা হোক আরও সহজ</p>

    <div class="ledger-chips">
      <span class="ledger-chip income"><i class="bi bi-arrow-down-left"></i> আয়</span>
      <span class="ledger-chip expense"><i class="bi bi-arrow-up-right"></i> ব্যয়</span>
      <span class="ledger-chip accent"><i class="bi bi-journal-text"></i> লেজার</span>
    </div>

    <?php if ($error): ?>
      <div class="alert py-2 small mb-3">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <span><?= e($error) ?></span>
      </div>
    <?php endif; ?>

    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Enter your username" required autofocus value="<?= e($_POST['username'] ?? '') ?>">
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
      </div>
      <button type="submit" class="btn btn-login w-100 mt-2">
        <i class="bi bi-box-arrow-in-right me-2"></i><span>Login to Dashboard</span>
      </button>
    </form>

    <div class="divider">Secure Access</div>
    <div class="foot-note">
      <i class="bi bi-shield-lock-fill me-1"></i>
      Protected by <strong><?= e(APP_NAME) ?></strong>
    </div>
  </div>
</div>
</body>
</html>