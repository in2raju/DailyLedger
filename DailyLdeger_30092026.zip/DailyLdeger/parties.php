<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$uid = $_SESSION['user_id'];

$type = get('type', 'customer') === 'supplier' ? 'supplier' : 'customer';

/* ---------------- Handle POST (add / edit / activate-deactivate party) ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'save') {
        $id      = (int)post('id');
        $ptype   = post('type') === 'supplier' ? 'supplier' : 'customer';
        $name    = trim(post('name'));
        $phone   = trim(post('phone'));
        $address = trim(post('address'));
        $opening = clean_amount(post('opening_due'));

        if ($name === '') {
            flash('danger', 'Party name is required.');
        } elseif ($id > 0) {
            $stmt = $pdo->prepare("UPDATE parties SET name=?, phone=?, address=?, opening_due=? WHERE id=? AND user_id=?");
            $stmt->execute([$name, $phone, $address, $opening, $id, $uid]);
            flash('success', 'Party updated.');
        } else {
            $stmt = $pdo->prepare("INSERT INTO parties (user_id, type, name, phone, address, opening_due) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$uid, $ptype, $name, $phone, $address, $opening]);
            flash('success', ucfirst($ptype) . ' added.');
        }
    } elseif ($action === 'toggle') {
        $id = (int)post('id');
        $stmt = $pdo->prepare("UPDATE parties SET status = IF(status='active','inactive','active') WHERE id=? AND user_id=?");
        $stmt->execute([$id, $uid]);
        flash('success', 'Status updated.');
    }
    redirect('parties.php?type=' . $type);
}

/* ---------------- List with running due ---------------- */
$search  = trim(get('q'));
$page    = max(1, (int)get('page', 1));
$perPage = 12;

$where  = "WHERE p.user_id = ? AND p.type = ?";
$params = [$uid, $type];
if ($search !== '') { $where .= " AND (p.name LIKE ? OR p.phone LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM parties p $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$p = paginate($total, $perPage, $page);

$sql = "SELECT p.*,
        COALESCE((SELECT SUM(amount) FROM due_transactions WHERE party_id=p.id AND type='due'),0) AS total_due,
        COALESCE((SELECT SUM(amount) FROM due_transactions WHERE party_id=p.id AND type='payment'),0) AS total_paid
        FROM parties p $where ORDER BY p.name LIMIT $perPage OFFSET {$p['offset']}";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$grandTotal = 0;
foreach ($rows as &$r) {
    $r['current_due'] = (float)$r['opening_due'] + (float)$r['total_due'] - (float)$r['total_paid'];
    $grandTotal += $r['current_due'];
}
unset($r);

$isCustomer = $type === 'customer';
$pageTitle  = $isCustomer ? 'Customers' : 'Suppliers';
$activeMenu = $isCustomer ? 'customers' : 'suppliers';
require_once __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 no-print flex-wrap gap-2">
  <h4 class="fw-bold mb-0">
    <i class="bi bi-<?= $isCustomer ? 'people' : 'truck' ?> text-primary-dl"></i>
    <?= $isCustomer ? 'Customer Due Ledger (Receivable)' : 'Supplier Due Ledger (Payable)' ?>
  </h4>
  <div>
    <div class="btn-group btn-group-sm me-2">
      <a href="?type=customer" class="btn btn-outline-primary <?= $isCustomer?'active':'' ?>">Customers</a>
      <a href="?type=supplier" class="btn btn-outline-primary <?= !$isCustomer?'active':'' ?>">Suppliers</a>
    </div>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#partyModal" onclick="openPartyModal()"><i class="bi bi-plus-lg"></i> Add <?= $isCustomer?'Customer':'Supplier' ?></button>
  </div>
</div>

<div class="card mb-3 no-print">
  <div class="card-body">
    <form method="get" class="row g-2">
      <input type="hidden" name="type" value="<?= $type ?>">
      <div class="col-md-4">
        <input type="text" name="q" class="form-control form-control-sm" placeholder="Search by name or phone..." value="<?= e($search) ?>">
      </div>
      <div class="col-md-2 d-grid">
        <button class="btn btn-sm btn-primary"><i class="bi bi-search"></i> Search</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between">
    <span><?= $isCustomer?'Customer':'Supplier' ?> List</span>
    <span class="fw-bold <?= $isCustomer?'text-warning':'text-purple' ?>">
      Total <?= $isCustomer?'Receivable':'Payable' ?>: <?= money($grandTotal) ?>
    </span>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead><tr><th>Name</th><th>Phone</th><th>Opening Due</th><th>New Due</th><th>Payment</th><th>Current Due</th><th>Status</th><th class="no-print">Action</th></tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">No <?= $type ?>s found.</td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><a href="party_ledger.php?id=<?= $r['id'] ?>" class="fw-semibold text-decoration-none"><?= e($r['name']) ?></a></td>
          <td class="small"><?= e($r['phone']) ?></td>
          <td><?= money($r['opening_due']) ?></td>
          <td class="text-success"><?= money($r['total_due']) ?></td>
          <td class="text-primary"><?= money($r['total_paid']) ?></td>
          <td><span class="badge <?= $r['current_due']>0?'badge-due':'badge-clear' ?> fs-6"><?= money($r['current_due']) ?></span></td>
          <td><span class="badge <?= $r['status']==='active'?'bg-success':'bg-secondary' ?>"><?= ucfirst($r['status']) ?></span></td>
          <td class="no-print text-nowrap">
            <a href="party_ledger.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-success" title="Add Due/Payment"><i class="bi bi-cash-stack"></i></a>
            <button class="btn btn-sm btn-outline-primary" onclick='openPartyModal(<?= json_encode($r) ?>)'><i class="bi bi-pencil"></i></button>
            <form method="post" class="d-inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button class="btn btn-sm btn-outline-secondary"><i class="bi bi-power"></i></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer no-print">
    <?= pagination_links('parties.php', ['type'=>$type,'q'=>$search], $p['currentPage'], $p['totalPages']) ?>
  </div>
</div>

<div class="modal fade" id="partyModal" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="party_id">
      <input type="hidden" name="type" value="<?= $type ?>">
      <div class="modal-header">
        <h5 class="modal-title" id="partyModalTitle">Add <?= $isCustomer?'Customer':'Supplier' ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2">
          <label class="form-label small">Name</label>
          <input type="text" name="name" id="party_name" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label small">Phone</label>
          <input type="text" name="phone" id="party_phone" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Address</label>
          <input type="text" name="address" id="party_address" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Opening Due</label>
          <input type="number" step="0.01" min="0" name="opening_due" id="party_opening" class="form-control" value="0">
          <div class="form-text">Any due balance carried over before using this system.</div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openPartyModal(data) {
  document.getElementById('partyModalTitle').textContent = data ? 'Edit <?= $isCustomer?"Customer":"Supplier" ?>' : 'Add <?= $isCustomer?"Customer":"Supplier" ?>';
  document.getElementById('party_id').value = data ? data.id : '';
  document.getElementById('party_name').value = data ? data.name : '';
  document.getElementById('party_phone').value = data ? data.phone : '';
  document.getElementById('party_address').value = data ? data.address : '';
  document.getElementById('party_opening').value = data ? data.opening_due : 0;
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
