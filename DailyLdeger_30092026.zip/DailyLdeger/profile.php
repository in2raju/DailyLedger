<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$uid = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$uid]);
$me = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = post('action');

    if ($action === 'update_profile') {
        $name     = trim(post('name'));
        $email    = trim(post('email'));
        $phone    = trim(post('phone'));
        $business = trim(post('business_name'));

        if ($name === '') {
            flash('danger', 'Name is required.');
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name=?, email=?, phone=?, business_name=? WHERE id=?");
            $stmt->execute([$name, $email, $phone, $business, $uid]);
            $_SESSION['user_name'] = $name;
            $_SESSION['business_name'] = $business;
            flash('success', 'Profile updated successfully.');
        }
    } elseif ($action === 'change_password') {
        $current = post('current_password');
        $new     = post('new_password');
        $confirm = post('confirm_password');

        // ---- Password strength rules ----
        $errors = [];
        if (!password_verify($current, $me['password'])) {
            $errors[] = 'Current password is incorrect.';
        }
        if (strlen($new) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        }
        if (!preg_match('/[A-Z]/', $new)) {
            $errors[] = 'New password must contain at least one uppercase letter (A-Z).';
        }
        if (!preg_match('/[a-z]/', $new)) {
            $errors[] = 'New password must contain at least one lowercase letter (a-z).';
        }
        if (!preg_match('/[0-9]/', $new)) {
            $errors[] = 'New password must contain at least one number (0-9).';
        }
        if (!preg_match('/[^A-Za-z0-9]/', $new)) {
            $errors[] = 'New password must contain at least one special character (!@#$%^&* etc.).';
        }
        if ($new !== $confirm) {
            $errors[] = 'New password and confirmation do not match.';
        }

        if (!empty($errors)) {
            foreach ($errors as $msg) flash('danger', $msg);
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password=? WHERE id=?");
            $stmt->execute([$hash, $uid]);
            flash('success', 'Password changed successfully.');
        }
    }
    redirect('profile.php');
}

$pageTitle = 'My Profile'; $activeMenu = '';
require_once __DIR__ . '/includes/header.php';
?>

<h4 class="fw-bold mb-3"><i class="bi bi-person-gear text-primary-dl"></i> My Profile</h4>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Business / Account Info</div>
      <div class="card-body">
        <form method="post">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update_profile">
          <div class="mb-2">
            <label class="form-label small">Full Name</label>
            <input type="text" name="name" class="form-control" required value="<?= e($me['name']) ?>">
          </div>
          <div class="mb-2">
            <label class="form-label small">Username</label>
            <input type="text" class="form-control" value="<?= e($me['username']) ?>" disabled>
          </div>
          <div class="mb-2">
            <label class="form-label small">Email</label>
            <input type="email" name="email" class="form-control" value="<?= e($me['email']) ?>">
          </div>
          <div class="mb-2">
            <label class="form-label small">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= e($me['phone']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label small">Business Name</label>
            <input type="text" name="business_name" class="form-control" value="<?= e($me['business_name']) ?>">
          </div>
          <button class="btn btn-primary"><i class="bi bi-save"></i> Update Profile</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header">Change Password</div>
      <div class="card-body">
        <form method="post" id="pwdForm">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="change_password">
          <div class="mb-2">
            <label class="form-label small">Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label small">New Password</label>
            <input type="password" name="new_password" id="newPassword" class="form-control" required minlength="8">
            <div class="form-text small">Minimum 8 characters with uppercase, lowercase, number & special character.</div>
          </div>
          <div class="mb-3">
            <label class="form-label small">Confirm New Password</label>
            <input type="password" name="confirm_password" id="confirmPassword" class="form-control" required minlength="8">
            <div class="invalid-feedback" id="confirmFeedback">Passwords do not match.</div>
          </div>
          <button class="btn btn-primary"><i class="bi bi-shield-lock"></i> Change Password</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const form = document.getElementById('pwdForm');
  const newPwd = document.getElementById('newPassword');
  const confirmPwd = document.getElementById('confirmPassword');
  const feedback = document.getElementById('confirmFeedback');

  function validate() {
    const val = newPwd.value;
    const rules = [
      val.length >= 8,
      /[A-Z]/.test(val),
      /[a-z]/.test(val),
      /[0-9]/.test(val),
      /[^A-Za-z0-9]/.test(val)
    ];
    newPwd.setCustomValidity(rules.every(Boolean) ? '' : 'Password does not meet the requirements.');
    newPwd.classList.toggle('is-invalid', !rules.every(Boolean));

    if (confirmPwd.value && confirmPwd.value !== val) {
      confirmPwd.setCustomValidity('Passwords do not match.');
      confirmPwd.classList.add('is-invalid');
      feedback.style.display = 'block';
    } else {
      confirmPwd.setCustomValidity('');
      confirmPwd.classList.remove('is-invalid');
      feedback.style.display = 'none';
    }
  }

  newPwd.addEventListener('input', validate);
  confirmPwd.addEventListener('input', validate);
  form.addEventListener('submit', validate);
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>